package com.jdc.misegundaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MisegundaapiApplication {

    public static void main(String[] args) {
        SpringApplication.run(MisegundaapiApplication.class, args);
    }

}
