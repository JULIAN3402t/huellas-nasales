package com.jdc.misegundaapi.enums;

public enum Sexo {

    M,
    F
}
