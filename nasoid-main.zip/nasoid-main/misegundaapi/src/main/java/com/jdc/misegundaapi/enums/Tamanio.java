package com.jdc.misegundaapi.enums;

public enum Tamanio {
TOY,
PEQUEÑO,
MEDIANO,
GRANDE,
GIGANTE,
    toy,
    pequeño,
    mediano,
    grande,
    Gigante

}