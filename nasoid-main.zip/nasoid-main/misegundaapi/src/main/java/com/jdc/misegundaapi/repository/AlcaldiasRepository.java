package com.jdc.misegundaapi.repository;

import com.jdc.misegundaapi.entity.AlcaldiasEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlcaldiasRepository extends JpaRepository<AlcaldiasEntity, Long> {
}
