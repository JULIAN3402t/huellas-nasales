package com.jdc.misegundaapi.repository;

import com.jdc.misegundaapi.entity.CanesEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CanesRepository extends JpaRepository<CanesEntity, Long> {
}
