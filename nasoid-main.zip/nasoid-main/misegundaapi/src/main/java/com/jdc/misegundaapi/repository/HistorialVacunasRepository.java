package com.jdc.misegundaapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface HistorialVacunasRepository extends JpaRepository<com.jdc.misegundaapi.entity.HistorialVacunasEntity, Long> {
}
