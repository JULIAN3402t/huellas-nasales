package com.jdc.misegundaapi.repository;

import com.jdc.misegundaapi.entity.RazasEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RazasRepository extends JpaRepository<RazasEntity, Long> {
}
