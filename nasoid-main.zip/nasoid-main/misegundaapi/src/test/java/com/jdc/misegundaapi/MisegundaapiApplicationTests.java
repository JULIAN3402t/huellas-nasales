package com.jdc.misegundaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MisegundaapiApplicationTests {

    @Test
    void contextLoads() {
    }

}
